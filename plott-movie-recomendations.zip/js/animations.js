import { gsap } from "gsap"

const tl = gsap.timeline();


tl.from(".bg-video", { opacity: 0, duration: 1.5 }) 
  .from(".header-content h1", { opacity: 0, y: 50, duration: 1 }, "-=0.5")
  .from(".scroll-indicator", { opacity: 0, y: -10, duration: 0.5 })